SELECT topology.DropTopology('upgrade_test');

